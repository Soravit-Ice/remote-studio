# การใช้งาน SDK และนำแอปขึ้นขาย

## ตั้งค่าร้านค้าหนึ่งครั้ง

1. Deploy migration `20261007160000_product_sdk_config` พร้อมเว็บ/server รุ่นที่รองรับ SDK Integration หลังตรวจใน staging และสำรองฐานข้อมูลตามขั้นตอน deploy ของร้านค้า
2. ตั้ง origin HTTPS จริง, issuer และ license signing keys, Supabase, Stripe, R2 private releases และ verification worker ของร้านค้าให้ครบ อย่า export config จาก demo mode
3. สำหรับ Electron เปิด OAuth server ของ Supabase และทำหน้า consent ตาม flow ของร้านค้า กำหนด public client แยกแต่ละแอป เปิด Authorization Code + PKCE และลง callback URI แบบ exact match จาก Admin
4. ตั้ง `DESKTOP_OAUTH_CLIENTS_JSON` เช่น `{"client-app-a":["AA"],"client-app-b":["BB"]}` ใน store API อย่าแชร์ client ระหว่างแอปโดยไม่จำเป็น SDK ไม่เปลี่ยนการตั้งค่า Supabase ให้เอง

## ทำต่อแอป

1. Admin สร้าง Product (DESKTOP_APP หรือ CLI_TOOL/SERVER_APP), product code, translations, platforms, delivery และ license policy/SKU/ราคาตามระบบเดิม
2. แท็บ SDK Integration: app ID เช่น `com.t2etech.appa`, public OAuth client ID สำหรับ Electron, macOS Team ID และ Windows signer SPKI SHA-256 จากใบรับรองจริง บันทึกพร้อม reason/reauth แล้ว export config
3. สร้างโปรเจกต์แยกผ่าน generator ตาม README ไม่ต้องย้าย app source เข้า repo ร้านค้า ทดสอบ login, key activation, account activation และ deactivate
4. ให้ main process/service เรียก `initialize()` ก่อนใช้งาน และ `dispose()` ก่อนปิด ใช้ `getAccess()` แสดงสถานะ; `login()` เปิด browser; `completeLogin(url)` ตรวจ callback/state/PKCE; `activate()` เลือก license ของ product ปัจจุบัน หรือ `activate(key)` สำหรับ key activation ตัวอย่าง renderer ไม่รับ OAuth token/private key
5. ต้องเรียก engine ที่มีค่าเงินจริงภายใน `runWithAccess({feature,operationId,recovery}, engine)` operation ID ต้องคงเดิมเมื่อ retry งานเดียวกัน Trial reserve ก่อนทำงาน, commit หลังสำเร็จ, release เมื่อยืนยันว่าล้มเหลว หาก crash และผลไม่ชัด SDK เก็บ UNCERTAIN และห้ามเริ่มงานใหม่จน reconcile ได้ ห้ามคืน quota อัตโนมัติเมื่อไม่รู้ว่าผลลัพธ์เกิดแล้วหรือยัง
6. ใช้ `recoverOperation` ตรวจหลักฐานของ engine จริงเพื่อคืน SUCCEEDED/FAILED/UNKNOWN ตัวอย่างใช้ output hash; production engine ควรมี durable operation journal/receipt ของตัวเอง เขียน recovery metadata ก่อนเริ่ม engine
7. ตัวอย่าง Node ใช้ key-provider AES-256-GCM + installation key เฉพาะเครื่องจาก secret manager; Electron ใช้ safeStorage และ lock file บน local disk ไม่มี plaintext fallback อย่าใช้ shared network filesystem หรือ MemorySdkStorage ใน production
8. ใช้ product code/app ID/API origin/issuer/user-data path คงเดิมในการอัปเดต แยก path ระหว่างผลิตภัณฑ์และ staging/production

## Build → upload → ขาย

1. ทดสอบแอป, เปลี่ยน version ใน package.json, commit lockfile และ public config ใน private app repo
2. Store Admin ผูก product กับ GitHub repository ID/ชื่อ repository และ release environments ที่อนุญาตตาม release API เดิม
3. ตั้ง protected GitHub environments `release-signing` และ `release-upload`; เก็บ Windows/macOS code-signing credentials และ Apple notarization credentials ใน secrets
4. เรียก reusable workflow ที่ generator ใส่ให้ (`.github/workflows/release.yml`) จาก workflow ที่ทำงานเมื่อ tag มี inputs product-code/version/release-api-origin ตัวอย่าง:

```yaml
name: Release
on:
  push:
    tags: ["[0-9]*"]
permissions:
  contents: read
  id-token: write
  actions: read
jobs:
  ship:
    uses: ./.github/workflows/release.yml
    with:
      product-code: AA
      version: ${{ github.ref_name }} # numeric tag เช่น 1.2.3
      release-api-origin: https://store.example
    secrets: inherit
```

ใช้ numeric tags เช่น `1.2.3` ที่ตรงกับ package.json; upload ใช้ GitHub OIDC bound กับ product/repository/tag/commit/environment

5. Workflow build Windows x64, macOS arm64/x64 → เซ็นและ notarize → สร้าง manifest → upload R2 ผ่าน release API → submit verification ยังไม่มีคำสั่ง publish อัตโนมัติ
6. รอ release READY/artifact VERIFIED ใน Admin ตรวจ checksum/signing/publisher/target ก่อน Publish และเผยแพร่ product/SKU
7. ทดสอบ checkout แบบ Stripe test → webhook สร้าง entitlement → account download → ติดตั้งบน Windows/macOS → login → activate → engine → restart/offline/update/deactivate แล้วจึงเปิดขายจริงและยืนยัน live payment ตามนโยบายร้านค้า
8. ลูกค้าซื้อบนเว็บ → สิทธิ์เข้า account → ดาวน์โหลด installer → ติดตั้ง → login บัญชีที่ซื้อหรือกรอก license key → activate → ใช้ feature ตามสิทธิ์

Admin export ตรวจ config ภายในร้านค้าเท่านั้น; `oauthExternallyVerified` ยังเป็น false จนมี acceptance evidence ภายนอก การติดตั้ง package อย่างเดียวไม่เปิดขายหรือ deploy ร้านค้าให้

## Key rotation และ migration

`jwksMode: pinned` เชื่อเฉพาะ public keys ที่ bundle; `store-keyring` ใช้ HTTPS store JWKS เมื่อเจอ kid ใหม่และเก็บ keyring ใน encrypted state ช่วย verify offline หลัง restart ต้องใช้ kid ใหม่สำหรับ key ใหม่ ห้ามเปลี่ยน key material ของ kid เดิม เก็บ public key เก่าสำหรับ lifetime certificates และ rollout key ใหม่ก่อนเริ่มเซ็น เก็บ SDK release signing key แยกจาก entitlement keys

Storage v1 เดิมยังอ่านได้และเพิ่ม namespace เมื่อเริ่ม SDK ใหม่ ห้ามลบ state, pending operations, trial fingerprint, device identity หรือ permanent certificate เพื่อแก้ migration สำหรับ Electron legacy adapter ส่งเข้า `ElectronSdkStorage(path,productCode,legacyStorage)` ครั้งแรกได้; เปลี่ยน Node plaintext state เป็น encrypted storage โดยอ่านครั้งเดียวจาก trusted local migration แล้วเก็บไฟล์เดิมอย่างปลอดภัย ห้ามใช้ compatibility FileLicenseStorage ใน production ใหม่

Node rotation: `current()` ให้ key ID/current 32-byte key; `get(id)` ยังคืน previous keys จน state ทั้งหมดถูกเขียนด้วย key ใหม่ แล้วค่อยเลิก previous keys เมื่อ restore/backups ไม่ต้องใช้แล้ว

Manual updates: `checkForUpdates(version)` → `authorizeDownload(artifactId)` → `downloadInstaller` (HTTPS/hash/size/platform) → `verifyInstallerSignature` (Team ID/SPKI pin) → native user confirmation → `openVerifiedInstaller(path,publishers,expectedSha256)` ไม่มี unattended auto-update

## เงื่อนไข production acceptance

ทดสอบ rejection ของ product อื่น/หมดสิทธิ์/เกินจำนวนเครื่อง, single-instance/lock conflict, cancellation, corrupt encrypted state, crash หลัง engine สำเร็จก่อน commit, key rotation แล้ว offline, revoked online lease, clean install และอัปเดตแบบคง identity ทำ staging/real signed installer acceptance บนทุก OS ที่ขาย SDK client ถูกแก้โดยผู้ครอบครองเครื่องได้ จึงไม่ใช่ขอบเขตความปลอดภัยของ API; ownership, quota, purchase, artifact eligibility และ OAuth scope ต้องตัดสินจาก server เสมอ

References: [Electron security](https://www.electronjs.org/docs/latest/tutorial/security), [safeStorage](https://www.electronjs.org/docs/latest/api/safe-storage), [Supabase OAuth native clients](https://supabase.com/docs/guides/auth/oauth-server/oauth-flows).

Electron starter bundle main process พร้อม runtime SDK ใน bundle เดียว โดย external เฉพาะ electron เพื่อให้ installer มี dependencies ครบ; esbuild ใช้ dist ของ SDK และไม่ต้องโหลด source repo ร้านค้า โปรเจกต์ Electron เดิมควรใช้วิธี bundle นี้เมื่อใช้ electron-builder/pnpm แทนการพึ่ง collector ให้คัดลอก bundledDependencies ซ้อนทั้งหมด
