#!/usr/bin/env node
import { parseArgs } from "node:util";
import { readFile, mkdir, cp, writeFile, access } from "node:fs/promises";
import { resolve, dirname, join } from "node:path";
import { fileURLToPath } from "node:url";
import { execFileSync } from "node:child_process";
import { ProductSdkConfigSchema } from "../dist/contracts.js";
const { values } = parseArgs({
  options: {
    config: { type: "string" },
    sdk: { type: "string" },
    out: { type: "string" },
    "public-key": { type: "string" },
  },
});
if (!values.config || !values.sdk || !values.out || !values["public-key"])
  throw new Error(
    "Usage: t2e-sdk-create --config product.config.json --sdk SDK.tgz --public-key TRUSTED-release-public-key.json --out ../my-app",
  );
const config = ProductSdkConfigSchema.parse(
  JSON.parse(await readFile(resolve(values.config), "utf8")),
);
const sdk = resolve(values.sdk),
  publicKey = resolve(values["public-key"]),
  target = resolve(values.out);
const base = resolve(dirname(fileURLToPath(import.meta.url)), "..");
execFileSync(
  process.execPath,
  [
    join(base, "scripts/verify-package.mjs"),
    join(dirname(sdk), "manifest.json"),
    join(dirname(sdk), "manifest.sig"),
    publicKey,
  ],
  { stdio: "inherit" },
);
const manifest = JSON.parse(
  await readFile(join(dirname(sdk), "manifest.json"), "utf8"),
);
if (
  join(dirname(sdk), manifest.fileName) !== sdk ||
  manifest.version !== config.sdkVersion
)
  throw new Error("Config and SDK release versions must match.");
try {
  await access(target);
  throw new Error("Destination exists; nothing overwritten.");
} catch (error) {
  if (error.code !== "ENOENT") throw error;
}
await mkdir(target, { recursive: true });
await cp(join(base, "templates", config.runtime), target, { recursive: true });
await mkdir(join(target, "vendor"));
for (const name of [manifest.fileName, "manifest.json", "manifest.sig"])
  await cp(join(dirname(sdk), name), join(target, "vendor", name));
await cp(publicKey, join(target, "vendor/sdk-release-public-key.json"));
await cp(
  join(base, "scripts/verify-package.mjs"),
  join(target, "vendor/verify-package.mjs"),
);
const pkg = JSON.parse(await readFile(join(target, "package.json"), "utf8"));
pkg.name = "@t2e/" + config.productCode.toLowerCase() + "-app";
pkg.description = config.productName;
pkg.dependencies = { "@t2e/license-sdk": "file:./vendor/" + manifest.fileName };
if (config.runtime === "electron") {
  pkg.build.appId = config.appId;
  pkg.build.productName = config.productName;
  pkg.build.artifactName =
    config.productCode.toLowerCase() + "-${version}-${os}-${arch}.${ext}";
  pkg.build.protocols = [
    {
      name: config.productName + " login",
      schemes: [config.appId.split("://")[0]],
    },
  ];
}
await writeFile(
  join(target, "package.json"),
  JSON.stringify(pkg, null, 2) + "\n",
);
await writeFile(
  join(target, "product.config.json"),
  JSON.stringify(config, null, 2) + "\n",
);
await writeFile(
  join(target, ".gitignore"),
  "node_modules/\nout/\ndist/\n.env*\n*.key\n",
);
console.log(
  "Created independent " +
    config.runtime +
    " app at " +
    target +
    ". Run pnpm install and customize its protected engine.",
);
