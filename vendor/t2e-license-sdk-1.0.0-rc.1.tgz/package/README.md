# @t2e/license-sdk

Private shared licensing SDK for independent Electron and Node applications sold through t2etech-store. Version **1.0.0-rc.1** is a release candidate. Local tests and package builds do not certify a deployed store, OAuth project, payment flow or signed installer.

The SDK is a separate repository. Each app commits a signed `.tgz` in its own `vendor/`; no paid/private package registry is required. Store website builds use the prebuilt contracts export and do not compile SDK source or build every app.

## Create an app

1. In deployed store Admin → Products → your product → **SDK Integration**, save a unique app ID, public OAuth client ID and installer publisher pins. Choose Electron or Node and export `product.config.json` when the configuration checks pass.
2. Electron: register a **public** OAuth client in the same Supabase project as the store, with the exact callback `com.t2etech.<app>://oauth/callback`; add the client-to-product mapping in the deployed `DESKTOP_OAUTH_CLIENTS_JSON`. There is no client secret in the app. Node can use key activation without OAuth.
3. Obtain `t2e-license-sdk-1.0.0-rc.1.tgz`, `manifest.json`, `manifest.sig`, and the SDK release public key through your trusted private distribution channel. Pin the key separately; do not trust a new key delivered with an untrusted archive.
4. Verify and generate an independent app:

```sh
node scripts/verify-package.mjs artifacts/manifest.json artifacts/manifest.sig release-public-key.json
node scripts/create-app.mjs --config /path/product.config.json \
  --sdk /path/t2e-license-sdk-1.0.0-rc.1.tgz \
  --public-key /trusted/sdk-release-public-key.json --out ../my-app
cd ../my-app
pnpm verify:sdk
pnpm install
pnpm start
```

The generator is also packaged as `t2e-sdk-create` after installation. For an existing app, verify first, copy the vendor files, then `pnpm add ./vendor/t2e-license-sdk-1.0.0-rc.1.tgz`. The archive includes runtime dependencies, so the SDK can be installed offline. Electron and your other app dependencies still require their own installation/cache.

5. Replace the starter engine with your real engine and gate it with `runWithAccess`. Commit a lockfile and use `pnpm install --frozen-lockfile` for subsequent reproducible installs. That flag checks the existing dependency lock; it does not upload anything or require a registry.
6. Build and sign native installers, submit through the app release workflow, wait for store verification, then publish through Admin. See [integration and selling steps](docs/integration.md).

## SDK source development

Node >=22.12 and pnpm 11.5.2. `pnpm install --frozen-lockfile`, `pnpm typecheck`, `pnpm test`, `pnpm build`.

Generate the SDK release key once with `pnpm keys:generate` (refuses overwrites). Keep `.keys/release-private.pem` private and back it up in a secret manager. It is separate from the store entitlement signing key and app signing certificates.

```sh
SDK_RELEASE_PRIVATE_KEY_FILE=.keys/release-private.pem pnpm pack:sdk
node scripts/verify-package.mjs artifacts/manifest.json artifacts/manifest.sig release-public-key.json
pnpm test:package
```

`--unsigned` is only for isolated CI fixtures. Customer/app distribution requires a signed manifest. Release CI uses a protected environment and an SDK signing secret; no npm publish step is included.

Exports: root core API; `/electron` OS-encrypted storage, native OAuth callbacks and verified manual installer updates; `/node` encrypted file storage with a key-provider contract; `/contracts` public Zod schemas; `/testing` in-memory fixtures; `/compat` migration facade. Private runtime exports throw under browser resolution.
