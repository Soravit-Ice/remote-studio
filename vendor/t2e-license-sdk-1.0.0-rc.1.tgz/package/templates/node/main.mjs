import { readFile } from "node:fs/promises";
import { resolve, join } from "node:path";
import { homedir } from "node:os";
import { randomUUID } from "node:crypto";
import { createInterface } from "node:readline/promises";
import { createLicenseSDKFromConfig } from "@t2e/license-sdk";
import { NodeEncryptedFileStorage } from "@t2e/license-sdk/node";
const config = JSON.parse(
  await readFile(new URL("./product.config.json", import.meta.url), "utf8"),
);
// Supply a unique 32-byte base64 key via this deployment's secret manager. Never commit it.
const key = Buffer.from(process.env.T2E_STORAGE_KEY_BASE64 ?? "", "base64");
if (key.length !== 32)
  throw new Error(
    "Configure T2E_STORAGE_KEY_BASE64 from your installation secret provider.",
  );
const namespace = [
  config.licenseApiOrigin,
  config.licenseIssuer,
  config.productCode,
  config.appId,
].join("|");
const storage = new NodeEncryptedFileStorage(
  resolve(
    process.env.T2E_STATE_PATH ??
      join(homedir(), ".t2etech", config.appId, "license-sdk.enc"),
  ),
  config.productCode,
  {
    current: async () => ({ id: "v1", key }),
    get: async (id) => (id === "v1" ? key : null),
  },
  namespace,
);
const sdk = createLicenseSDKFromConfig(config, {
  storage,
  platform:
    process.platform === "darwin"
      ? "MACOS"
      : process.platform === "win32"
        ? "WINDOWS"
        : "LINUX",
  architecture: process.arch === "arm64" ? "ARM64" : "X64",
});
try {
  if (process.argv.includes("--activate")) {
    // Read stdin rather than command-line arguments; a service should use its secret provider.
    const input = createInterface({
      input: process.stdin,
      output: process.stderr,
      terminal: false,
    });
    const license = await input.question("License key (stdin): ");
    input.close();
    await sdk.activate(license.trim());
  }
  if (process.argv.includes("--run"))
    await sdk.runWithAccess(
      { feature: "export", operationId: randomUUID() },
      async () => {
        console.log(
          "Replace this callback with your protected CLI/service work.",
        );
      },
    );
  else console.log(await sdk.getAccess());
} finally {
  await sdk.dispose();
}
