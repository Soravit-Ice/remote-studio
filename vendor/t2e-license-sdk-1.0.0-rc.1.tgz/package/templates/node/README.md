# Independent Node application

Run `pnpm verify:sdk`, then `pnpm install` and commit the generated lockfile. CI uses `pnpm install --frozen-lockfile`.

Set `T2E_STORAGE_KEY_BASE64` to a unique, stable, 32-byte random key supplied by your deployment secret manager (never put it in source, the SDK package, or product config). The sample uses key ID v1. Production providers can rotate keys by retaining lookup access to old IDs. State defaults to `~/.t2etech/<appId>/license-sdk.enc`; keep that encrypted state and the provider keys together across app updates.

`node main.mjs --activate` reads a license key from stdin, so it does not enter shell history. `node main.mjs --run` runs the sample export under `runWithAccess`. Replace that function with your engine. Node apps use license-key activation; this starter intentionally needs no browser or OAuth. Machine trials support native Windows/macOS identifiers; configure `trialEnabled: false` for Linux/headless deployments.
