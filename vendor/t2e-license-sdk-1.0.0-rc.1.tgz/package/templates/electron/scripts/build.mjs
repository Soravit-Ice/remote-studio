import { build } from "esbuild";
import { cp, mkdir, rm } from "node:fs/promises";
await rm("dist", { recursive: true, force: true });
await mkdir("dist", { recursive: true });
// One bundle preserves SDK module/error identity and includes its bundled runtime dependencies.
// electron-builder's pnpm collector otherwise omits nested bundledDependencies.
await build({
  entryPoints: ["src/main.cjs"],
  outfile: "dist/main.cjs",
  bundle: true,
  platform: "node",
  format: "cjs",
  target: "node22",
  external: ["electron"],
  sourcemap: false,
});
for (const file of ["preload.cjs", "index.html", "renderer.js", "style.css"])
  await cp("src/" + file, "dist/" + file);
