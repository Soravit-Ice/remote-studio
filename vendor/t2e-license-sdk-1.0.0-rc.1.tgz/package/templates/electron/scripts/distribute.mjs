import { readdir } from "node:fs/promises";
import { execFile } from "node:child_process";
import { promisify } from "node:util";
import { resolve } from "node:path";
import spawn from "cross-spawn";
if (!["darwin", "win32"].includes(process.platform))
  throw new Error("Only Windows/macOS distribution is supported.");
if (!process.env.CSC_LINK || !process.env.CSC_KEY_PASSWORD)
  throw new Error("Distribution requires a signing identity and password.");
if (
  process.platform === "darwin" &&
  (!process.env.APPLE_ID ||
    !process.env.APPLE_APP_SPECIFIC_PASSWORD ||
    !process.env.APPLE_TEAM_ID)
)
  throw new Error("macOS distribution requires notarization credentials.");
const arch = process.argv[2];
if (
  !["arm64", "x64"].includes(arch) ||
  (process.platform === "win32" && arch !== "x64")
)
  throw new Error("Use x64 on Windows; arm64 or x64 on macOS.");
const result = spawn.sync(
  "pnpm",
  [
    "exec",
    "electron-builder",
    process.platform === "darwin" ? "--mac" : "--win",
    "--" + arch,
    "--publish",
    "never",
  ],
  {
    stdio: "inherit",
    env: {
      ...process.env,
      CSC_FOR_PULL_REQUEST: "false",
      CSC_IDENTITY_AUTO_DISCOVERY: "true",
    },
  },
);

if (result.status !== 0) process.exit(result.status ?? 1);
if (process.platform === "darwin") {
  const execute = promisify(execFile);
  const files = (await readdir("out")).filter(
    (name) => name.endsWith(".dmg") && name.includes("-" + arch + "."),
  );
  if (files.length !== 1) throw new Error("Expected one freshly built DMG.");
  try {
    await execute(
      "/usr/bin/xcrun",
      [
        "notarytool",
        "submit",
        resolve("out", files[0]),
        "--apple-id",
        process.env.APPLE_ID,
        "--password",
        process.env.APPLE_APP_SPECIFIC_PASSWORD,
        "--team-id",
        process.env.APPLE_TEAM_ID,
        "--wait",
      ],
      { timeout: 1_200_000, maxBuffer: 1024 * 1024 },
    );
    await execute(
      "/usr/bin/xcrun",
      ["stapler", "staple", resolve("out", files[0])],
      {
        timeout: 120_000,
      },
    );
  } catch {
    console.error(
      "DMG notarization/stapling failed. No release manifest will be emitted.",
    );
    process.exit(1);
  }
}
