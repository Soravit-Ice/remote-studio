import { readdir, writeFile, stat } from "node:fs/promises";
import { resolve, basename } from "node:path";
import { execFile } from "node:child_process";
import { promisify } from "node:util";
const arch = process.argv[2];
if (
  !["x64", "arm64"].includes(arch) ||
  !["darwin", "win32"].includes(process.platform)
)
  throw new Error("Unsupported target");
const execute = promisify(execFile),
  directory = resolve("out");
const files = (await readdir(directory)).filter((name) =>
  name.endsWith(process.platform === "darwin" ? ".dmg" : ".exe"),
);
if (files.length !== 1)
  throw new Error("Expected exactly one freshly built installer");
const artifacts = [];
for (const name of files) {
  if (!(await stat(resolve(directory, name))).isFile())
    throw new Error("Invalid installer");
  try {
    if (process.platform === "darwin") {
      await execute("/usr/bin/xcrun", [
        "stapler",
        "validate",
        resolve(directory, name),
      ]);
      await execute("/usr/sbin/spctl", [
        "--assess",
        "--type",
        "open",
        "--context",
        "context:primary-signature",
        resolve(directory, name),
      ]);
    } else {
      const result = await execute(
        "powershell.exe",
        [
          "-NoProfile",
          "-NonInteractive",
          "-Command",
          "(Get-AuthenticodeSignature -LiteralPath $env:T2E_INSTALLER_PATH).Status.ToString()",
        ],
        {
          env: { ...process.env, T2E_INSTALLER_PATH: resolve(directory, name) },
        },
      );
      if (result.stdout.trim() !== "Valid") throw new Error();
    }
  } catch {
    throw new Error(
      "Installer signing/notarization verification failed. No manifest was emitted.",
    );
  }
  artifacts.push({
    fileName: basename(name),
    deliveryType: "DESKTOP_INSTALLER",
    platform: process.platform === "darwin" ? "MACOS" : "WINDOWS",
    architecture: arch === "arm64" ? "ARM64" : "X64",
    mimeType:
      process.platform === "darwin"
        ? "application/x-apple-diskimage"
        : "application/vnd.microsoft.portable-executable",
    codeSigned: true,
    notarized: process.platform === "darwin",
  });
}
await writeFile(
  resolve(directory, "manifest-" + arch + "-" + process.platform + ".json"),
  JSON.stringify(artifacts, null, 2),
);
