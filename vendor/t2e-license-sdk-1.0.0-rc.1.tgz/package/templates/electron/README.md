# Independent Electron app

This is a small main/preload/renderer starter. Replace the sample protected export engine in `src/main.cjs` with your own app. Every app has a distinct product code, app ID, OAuth client and encrypted user-data directory.

1. `pnpm verify:sdk`
2. `pnpm install` once; commit `pnpm-lock.yaml`, public config and signed vendor files to your private app repository.
3. `pnpm install --frozen-lockfile` in CI.
4. `pnpm start`; use `pnpm package:dir` for a local unsigned smoke build.
5. Set your real version in package.json. Configure GitHub `release-signing` and `release-upload` environments and store product repository binding.
6. Add a tag-triggered caller for `.github/workflows/release.yml` with product-code/version/release-api-origin and signing secrets. That reusable workflow builds Windows x64 and macOS arm64/x64, signs/notarizes and submits to the store for verification. It does not publish the release.
7. Publish a verified READY release through store Admin after checking product, installer and download.

The main process owns OAuth, secrets, activation, license gates, filesystem writes and update installation. The sandboxed renderer receives only UI-safe access state and fixed commands. Always run the real protected engine inside `sdk.runWithAccess`; hiding a button alone does not enforce licensing. The sample `--sdk-smoke` initializes local encrypted storage without network or protocol registration.

The public product config cannot prove external OAuth callback registration, successful checkout, or operating-system signing. Complete those acceptance checks before selling. See the SDK `docs/integration.md` for account activation, migration and crash recovery.
