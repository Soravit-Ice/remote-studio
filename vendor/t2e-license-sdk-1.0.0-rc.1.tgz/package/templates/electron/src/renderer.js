const status = document.querySelector("#status");
async function invoke(command, key) {
  try {
    status.textContent = JSON.stringify(
      await window.appApi.invoke(command, key),
      null,
      2,
    );
  } catch {
    status.textContent = "The application could not complete this operation.";
  }
}
for (const button of document.querySelectorAll("[data-command]"))
  button.addEventListener("click", () => invoke(button.dataset.command));
document.querySelector("#activate").addEventListener("click", () => {
  const field = document.querySelector("#key"),
    key = field.value;
  field.value = "";
  void invoke("activateKey", key);
});
void invoke("status");
