const { app, BrowserWindow, ipcMain, dialog, shell } = require("electron");
process.on("uncaughtException", (error) => {
  console.error(
    process.argv.includes("--sdk-smoke") ? error : "APP_START_FAILED",
  );
  app.exit(1);
});

const { mkdirSync, readFileSync } = require("node:fs");
const { readFile, writeFile, rename, rm } = require("node:fs/promises");
const { createHash, randomUUID } = require("node:crypto");
const { join } = require("node:path");
const {
  createLicenseSDKFromConfig,
  LicenseClientError,
} = require("@t2e/license-sdk");
const {
  ElectronSdkStorage,
  bindElectronOAuth,
  downloadInstaller,
  verifyInstallerSignature,
  openVerifiedInstaller,
} = require("@t2e/license-sdk/electron");
const here = __dirname;
const { ProductSdkConfigSchema } = require("@t2e/license-sdk/contracts");
const config = ProductSdkConfigSchema.parse(
  JSON.parse(readFileSync(join(here, "../product.config.json"), "utf8")),
);
if (!["win32", "darwin"].includes(process.platform))
  throw new Error("Electron starter supports Windows/macOS.");
const userData =
  process.argv.includes("--sdk-smoke") && process.env.T2E_SDK_SMOKE_DATA
    ? process.env.T2E_SDK_SMOKE_DATA
    : join(app.getPath("appData"), config.appId);
mkdirSync(userData, { recursive: true, mode: 0o700 });
app.setPath("userData", userData);
if (!app.requestSingleInstanceLock()) app.exit(0);

const sdk = createLicenseSDKFromConfig(config, {
  storage: new ElectronSdkStorage(
    join(app.getPath("userData"), "license-sdk.enc"),
    config.productCode,
  ),
  openExternal: (url) => shell.openExternal(url),
  platform: process.platform === "darwin" ? "MACOS" : "WINDOWS",
  architecture: process.arch === "arm64" ? "ARM64" : "X64",
  recoverOperation: async (operation) => {
    if (!operation.recovery?.path || !operation.recovery?.sha256)
      return "UNKNOWN";
    try {
      return createHash("sha256")
        .update(await readFile(operation.recovery.path))
        .digest("hex") === operation.recovery.sha256
        ? "SUCCEEDED"
        : "UNKNOWN";
    } catch {
      return "UNKNOWN";
    }
  },
});
if (process.argv.includes("--sdk-smoke")) {
  void app
    .whenReady()
    .then(async () => {
      await sdk.initialize();
      await sdk.dispose();
      console.log("T2E_SDK_SMOKE_OK");
      app.exit(0);
    })
    .catch(() => {
      console.error("SDK_SMOKE_FAILED");
      app.exit(1);
    });
} else {
  bindElectronOAuth(sdk, config.oauthRedirectUri, () => {
    /* Show a sanitized retry message in your product UI. */
  });
  void app
    .whenReady()
    .then(async () => {
      await sdk.initialize();
      let window = new BrowserWindow({
        width: 900,
        height: 640,
        webPreferences: {
          preload: join(here, "preload.cjs"),
          sandbox: true,
          contextIsolation: true,
          nodeIntegration: false,
        },
      });
      window.webContents.session.setPermissionRequestHandler(
        (_contents, _permission, callback) => callback(false),
      );
      window.webContents.session.setPermissionCheckHandler(() => false);
      window.webContents.setWindowOpenHandler(() => ({ action: "deny" }));
      window.webContents.on("will-navigate", (event) => event.preventDefault());
      let busy = false,
        update,
        installer;
      ipcMain.handle("app:command", async (event, command, key) => {
        if (
          event.sender !== window.webContents ||
          event.senderFrame !== window.webContents.mainFrame
        )
          throw new Error("Untrusted frame");
        if (busy) return { error: "APP_BUSY" };
        busy = true;
        try {
          switch (command) {
            case "status":
              return await sdk.getAccess();
            case "login":
              return await sdk.login();
            case "logout":
              return await sdk.logout();
            case "deactivate":
              return await sdk.deactivate();
            case "activateAccount":
              await sdk.activate();
              return { activated: true };
            case "activateKey":
              if (typeof key !== "string" || key.length > 200)
                throw new Error("Invalid key");
              await sdk.activate(key);
              return { activated: true };
            case "openStore":
              await shell.openExternal(
                new URL("/account", config.licenseApiOrigin).href,
              );
              return { opened: true };
            case "export": {
              const choice = await dialog.showSaveDialog(window, {
                defaultPath: "example.txt",
              });
              if (choice.canceled || !choice.filePath)
                return { cancelled: true };
              const text = "Replace this example with your protected engine.\n",
                path = choice.filePath;
              await sdk.runWithAccess(
                {
                  feature: "export",
                  operationId: randomUUID(),
                  recovery: {
                    path,
                    sha256: createHash("sha256").update(text).digest("hex"),
                  },
                },
                async () => {
                  const tmp = path + "." + randomUUID() + ".tmp";
                  try {
                    await writeFile(tmp, text, { flag: "wx" });
                    await rename(tmp, path);
                  } finally {
                    await rm(tmp, { force: true });
                  }
                },
              );
              return { exported: true };
            }
            case "checkUpdates": {
              const result = await sdk.checkForUpdates(app.getVersion());
              update = result.hasUpdate ? result.artifacts[0] : undefined;
              installer = undefined;
              return {
                hasUpdate: Boolean(update),
                version: result.version,
                releaseNotes: result.releaseNotes,
              };
            }
            case "downloadUpdate": {
              if (!update) return { error: "CHECK_UPDATES_FIRST" };
              const authorization = await sdk.authorizeDownload(update.id);
              installer = await downloadInstaller(
                authorization,
                join(app.getPath("userData"), "updates"),
                {
                  platform: process.platform === "darwin" ? "MACOS" : "WINDOWS",
                  architecture: process.arch === "arm64" ? "ARM64" : "X64",
                },
              );
              await verifyInstallerSignature(
                installer,
                config.installerPublishers,
              );
              return { downloaded: true };
            }
            case "installUpdate": {
              if (!installer) return { error: "DOWNLOAD_UPDATE_FIRST" };
              const answer = await dialog.showMessageBox(window, {
                type: "question",
                message: "Open the verified update installer?",
                buttons: ["Cancel", "Install"],
                defaultId: 0,
                cancelId: 0,
              });
              if (answer.response === 1)
                await openVerifiedInstaller(
                  installer,
                  config.installerPublishers,
                  update.sha256,
                );
              return { opened: answer.response === 1 };
            }
            default:
              return { error: "UNKNOWN_COMMAND" };
          }
        } catch (error) {
          return {
            error:
              error instanceof LicenseClientError
                ? error.code
                : "APP_OPERATION_FAILED",
          };
        } finally {
          busy = false;
        }
      });
      await window.loadFile(join(here, "index.html"));
      app.on("window-all-closed", () => app.quit());
      let exiting = false;
      app.on("before-quit", (event) => {
        if (!exiting) {
          event.preventDefault();
          exiting = true;
          void sdk.dispose().finally(() => app.quit());
        }
      });
    })
    .catch(() => {
      console.error("APP_START_FAILED");
      app.exit(1);
    });
}
