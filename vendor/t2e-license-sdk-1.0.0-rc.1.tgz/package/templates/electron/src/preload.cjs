const { contextBridge, ipcRenderer } = require("electron");
const commands = new Set([
  "status",
  "login",
  "logout",
  "activateKey",
  "activateAccount",
  "deactivate",
  "export",
  "checkUpdates",
  "downloadUpdate",
  "installUpdate",
  "openStore",
]);
contextBridge.exposeInMainWorld("appApi", {
  invoke: (command, key) => {
    if (!commands.has(command)) throw new Error("Unknown command");
    return ipcRenderer.invoke(
      "app:command",
      command,
      command === "activateKey" ? key : undefined,
    );
  },
});
